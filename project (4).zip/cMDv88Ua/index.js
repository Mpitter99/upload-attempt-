  //document.getElementById("count-el").innerText = 5

let countEl = document.getElementById("count-el")
console.log(countEl)

let saveEl = document.getElementById("save-el")

count = 0

//"document.getElementById()" retrieves the html id
//".innertext =" allows you to modify the value  

function increment() {
    count += 1
    countEl.innerText = count 
}

//innertext does not display elements that are not readable by humans
//textcontent is a good alternative for this problem

function save() {
    let saving = count + " - "
    saveEl.textContent += saving
    console.log(count)
    countEl.textContent = 0
    count = 0
}

// let username = "impitterbro"
// let message = "you have tree new notifications"
// console.log(message + ',' + username + "!")

// let name = "Michael"
// let greeting = "Hi, my name is"
// let myGreeting = greeting + " " + name
// console.log(myGreeting)